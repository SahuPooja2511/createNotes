import { LightningElement, api, wire, track } from 'lwc';
import { getRecord, getFieldValue } from "lightning/uiRecordApi";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import { getObjectInfo, getPicklistValues } from 'lightning/uiObjectInfoApi';

import Brand_Association_OBJECT from '@salesforce/schema/Brand_Association__c';
import Title_FIELD from "@salesforce/schema/Brand_Association__c.Notes_Title__c";
import Brand_FIELD from "@salesforce/schema/Brand_Association__c.Brand__c";
import Name_FIELD from "@salesforce/schema/Account.Name";

import createNote from "@salesforce/apex/CreateNotesController.createNote";
import getBrandAssociation from "@salesforce/apex/CreateNotesController.getBrandAssociation";
import getNoteContent from "@salesforce/apex/CreateNotesController.getNoteContent";

export default class AccountNotes extends LightningElement {
    @api recordId;

    @track isShow = false;
    @track loading = false;
    @track records = [];
    @track brandOptions = [];
    @track titlePickList = []
    @track noteId;
    @track brandValue = null;

    @track accountName;
    @track defaultRecordTypeId;

    @track isNewNote = false;
    @track title = null;
    @track content;
    @track headerValue;

    get isNextDisabled() {
        return (this.title == null || this.brandValue == null) ? true : false;
    }


    @api
    handleAccountOpen(recId) {
        console.log('brandValue', this.brandValue);
        this.noteId = recId;
        this.records = [];
        this.title = null;
        this.content = null;
        this.brandValue = null;
        if (this.noteId) {
            this.headerValue = 'Edit Note';
            this.handleNoteEdit();
        } else {
            this.headerValue = 'New Note';
            this.isShow = true;
        }
    }

    @wire(getObjectInfo, { objectApiName: Brand_Association_OBJECT })
    wiredObjectInfo({ error, data }) {
        if (data) {
            this.defaultRecordTypeId = data.defaultRecordTypeId;
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$defaultRecordTypeId', fieldApiName: Title_FIELD })
    staffingByWired({ data, error }) {
        if (data && data.values) {
            let titleList = [];
            for (var key in data.values) {
                titleList.push({
                    label: data.values[key].label, value: data.values[key].value
                });
            }
            this.titlePickList = titleList;
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$defaultRecordTypeId', fieldApiName: Brand_FIELD })
    staffingByWiredBrand({ data, error }) {
        if (data && data.values) {
            let brandList = [{ label: '--None--', value: 'None' }];
            for (var key in data.values) {
                brandList.push({
                    label: data.values[key].label, value: data.values[key].value
                });
            }
            this.brandOptions = brandList;
        }
    }

    @wire(getRecord, { recordId: "$recordId", fields: [Name_FIELD] })
    wiredAccount({ data }) {
        if (data) {
            let name = getFieldValue(data, Name_FIELD);
            this.accountName = name;
        }
    }

    handleBrandChange(event) {
        this.records = [];
        this.brandValue = event.detail.value == 'None' ? '' : event.detail.value;
    }

    handleTitleChange(event) {
        this.title = event.detail.value;
    }

    handleBrandAssociation() {
        if (this.brandValue != null && this.title != null) {
            this.loading = true;
            getBrandAssociation({ accountId: this.recordId, brand: this.brandValue, notesTitle: this.title }).then(data => {
                this.brandAssociation = JSON.parse(data);
                //Add Brand Association Record 
                let brandRecord = {
                    Id: this.brandAssociation.Id,
                    Name: this.brandAssociation.Name
                };
                this.records.push(brandRecord);

                // Add Account record
                let accRecord = {
                    Id: this.recordId,
                    Name: this.accountName
                };
                this.records.push(accRecord);
                this.loading = false;
            }).catch(error => {
                console.log('error:::', error);
                this.loading = false;
            });
        }
    }

    handleNoteEdit() {
        this.loading = true;
        this.records = [];
        getNoteContent({ contentNoteId: this.noteId })
            .then(result => {
                for (let record in result.parentIdList) {
                    let note = {
                        Id: record,
                        Name: result.parentIdList[record].split(';')[0]
                    };
                    this.records.push(note);
                    if (result.parentIdList[record].split(';')[1]) {
                        this.brandValue = result.parentIdList[record].split(';')[1];
                    }
                };
                this.title = result.title;
                this.content = result.content;
                this.noteId = result.noteContentId;
                this.isShow = true;
                this.isNewNote = true;
                this.loading = false;
            }).catch(error => {
                console.log('error:::', error);
                this.loading = false;
            });
    }

    handleNext() {
        this.loading = true;
        this.handleBrandAssociation();
        this.isNewNote = true;
        this.loading = false;
    }

    closeQuickAction() {
        this.isShow = false;
        this.isNewNote = false;
    }

    handleChange(event) {
        let value = event.target.value;
        let name = event.target.name;
        if (name === "title") {
            this.title = value ? value.trim() : '';
        } else if (name === "content") {
            this.content = value ? value.trim() : '';
        }
    }

    createNote() {
        this.loading = true;
        if (this.title && this.content) {
            let parentIds = [];
            this.records.forEach(parent => {
                parentIds.push(parent.Id)
            });
            createNote({
                parentIds: parentIds,
                title: this.title,
                content: this.content,
                noteId: this.noteId

            })
                .then((data) => {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: "Success",
                            message: "Note Created!",
                            variant: "success"
                        })
                    );
                    this.dispatchEvent(new CustomEvent("savenote"));
                    this.closeQuickAction();
                    this.loading = false;
                })
                .catch((error) => {
                    let msg = "";
                    if (Array.isArray(error.body)) {
                        msg = error.body.map((e) => e.message).join(", ");
                    } else if (typeof error.body.message === "string") {
                        msg = error.body.message;
                        this.loading = false;
                    }
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: "Error",
                            message: msg,
                            variant: "error"
                        })
                    );
                });
            this.loading = false;
        } else {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: "Error",
                    message: 'Please enter title and content',
                    variant: "error"
                })
            );
            this.loading = false;
        }
    }
}