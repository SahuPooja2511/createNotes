import { LightningElement, track, wire, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import LightningConfirm from 'lightning/confirm';

import getallRelatedNotes from '@salesforce/apex/CreateNotesController.getallRelatedNotes';
import getPickListValues from '@salesforce/apex/CreateNotesController.getPickListValues';
import deleteNote from '@salesforce/apex/CreateNotesController.deleteNote';

const actions = [
    { label: 'Edit', name: 'edit' },
    { label: 'Delete', name: 'delete' },
];

export default class CreateNotes extends NavigationMixin(LightningElement) {
    @api recordId;

    @track isLoading = false;
    @track sortDirection = 'desc';
    @track orderby = 'CreatedDate';
    @track orderby_ = 'CreatedDate';
    @track relatedNoteList = [];

    @track noteCreatedby;
    @track lastModifiedBy;
    @track brandOptions;
    @track noteNameOptions;
    @track brandValue;
    @track noteByValue;
    @track noteNameValue;
    @track lastModifiedByValue;
    @track noteContentId;
    defaultRecordTypeId;
    isNotesView = false;
    activeSections;

    columns = [
        { label: 'Brand', fieldName: 'brandName', type: 'text', sortable: 'true' },
        { label: 'Category', fieldName: 'noteName', type: 'text', sortable: "true" },
        { label: 'Content', fieldName: 'noteContent', type: 'text', sortable: "true", wrapText:"true"},
        { label: 'Modified', fieldName: 'modifiedDate', type: 'text', sortable: 'true' },
        { label: 'LastModified By', fieldName: 'lastModifiedBy', type: 'text', sortable: 'true' },
        { label: 'Created', fieldName: 'createdDate', type: 'text', sortable: 'true' },
        { label: 'Created By', fieldName: 'noteCreatedBy', type: 'text', sortable: 'true' },
        { type: 'action', typeAttributes: { rowActions: actions }, },
    ];

    get isDataFound() {
        return this.relatedNoteList.length > 0;
    }

    connectedCallback() {
        this.getAllPicklistValues();
        this.handleNotesList();
    }

    handleAllViewNotes(){
        this.activeSections = [...Array(this.relatedNoteList.length).keys()];
        this.isNotesView = true;
    }

    closeNotesView(){
        this.isNotesView = false;
    }

    //Call apex to get all related notes of Account And Brand Association
    handleNotesList() {
        this.isLoading = true;
        getallRelatedNotes({ accountId: this.recordId, noteNameValue: this.noteNameValue, brandValue: this.brandValue, noteByValue: this.noteByValue, lastModifiedByValue: this.lastModifiedByValue, sortDir: this.sortDirection, orderby: this.orderby_ })
            .then(result => {
                if (result !== null) {
                   // console.log('result List ::'+ JSON.stringify(result.notesList));
                    this.relatedNoteList = result.notesList;  
                    console.log('this.relatedNoteList :: '+ JSON.stringify(this.relatedNoteList));  
                    this.isLoading = false;
                }
            })
            .catch((error) => {
                this.error = error;
                this.isLoading = false;
                console.log('error  ', error);
            });
    }

    getAllPicklistValues() {
        getPickListValues({ accountId: this.recordId })
            .then(result => {
                if (result !== null) {
                    let noteByUsers = [{ label: '--None--', value: 'None' }];
                    let noteLastModifiedByUsers = [{ label: '--None--', value: 'None' }];
                    let brand = [{ label: '--None--', value: 'None' }];
                    let notename = [{ label: '--None--', value: 'None' }];
                    for (var key in result.noteNameList) {
                        notename.push({
                            label: result.noteNameList[key], value: result.noteNameList[key]
                        });
                    }
                    for (var key in result.brandList) {
                        brand.push({
                            label: result.brandList[key], value: result.brandList[key]
                        });
                    }
                    for (var key in result.noteCreatedByList) {
                        noteByUsers.push({
                            label: result.noteCreatedByList[key], value: result.noteCreatedByList[key]
                        });
                    }
                    for (var key in result.noteLastModifiedByList) {
                        noteLastModifiedByUsers.push({
                            label: result.noteLastModifiedByList[key], value: result.noteLastModifiedByList[key]
                        });
                    }

                    this.brandOptions = brand;
                    this.noteNameOptions = notename;
                    this.noteCreatedby = noteByUsers;
                    this.lastModifiedBy = noteLastModifiedByUsers;
                }
            })
            .catch((error) => {
                this.error = error;
                this.isLoading = false;
                console.log('error  ', error);
            });
    }

    //Handle Note Name filter
    handleNoteValueChange(event) {
        this.noteNameValue = event.target.value == 'None' ? null : event.target.value;
        this.handleNotesList();
    }

    //Handle Brand filter
    handleBrandChange(event) {
        this.brandValue = event.target.value == 'None' ? null : event.target.value;
        this.handleNotesList();
    }

    //Handle Note By filter
    handlenoteByChange(event) {
        this.noteByValue = event.target.value == 'None' ? null : event.target.value;
        this.handleNotesList();
    }

    //Handle Note By filter
    handlelastModifiedByChange(event) {
        this.lastModifiedByValue = event.target.value == 'None' ? null : event.target.value;
        this.handleNotesList();
    }

    //Handle ResetButton
    handleResetAll() {
        this.isLoading = true;
        this.noteNameValue = null;
        this.brandValue = null;
        this.noteByValue = null;
        this.lastModifiedByValue = null;
        this.handleNotesList();
        this.getAllPicklistValues();
    }

    async handleRowAction(event) {
        this.isLoading = true;
        const row = event.detail.row;
        let actionName = event.detail.action.name;
        this.noteContentId = row.notecontentdumentId;
        console.log('actionName::', actionName);
        if (actionName == 'delete') {
            const result = await LightningConfirm.open({
                message: 'Do you want to delete this Note?',
                variant: 'headerless',
                label: 'Do you want to delete this Note?',
            });
            if (result) {
                this.isLoading = true;
                deleteNote({ contentDocumentId: row.notecontentdumentId })
                    .then(result => {
                        if (result != null) {
                            this.dispatchEvent(
                                new ShowToastEvent({
                                    title: "Success",
                                    message: result + " Deleted Successfully!",
                                    variant: "success"
                                })
                            )
                            this.handleResetAll();
                            this.isLoading = false;
                        }
                    })
                    .catch((error) => {
                        this.error = error;
                        this.isLoading = false;
                        console.log('error  ', error);
                    });
            }
            this.isLoading = false;
        } else {
            this.handleCreateNewNote();
            this.isLoading = false;
        }

    }

    // Methods to handle sorting data
    doSorting(event) {
        this.sortDirection = event.detail.sortDirection;
        let orderby = event.detail.fieldName;
        if(orderby == 'modifiedDate'){
            this.orderby_ = 'LastModifiedDate';
            this.handleNotesList();
        }else{
        new Promise(
            (resolve, reject) => {
                setTimeout(() => {
                    this.sortData(orderby, this.sortDirection);
                    resolve();
                }, 0);
            }).then(
                () => this.isLoading = false
            );
        }

        this.orderby = orderby;
    }

    sortData(fieldname, direction) {
        let parseData = JSON.parse(JSON.stringify(this.relatedNoteList));
        let keyValue = (a) => {
            return a[fieldname];
        };
        let isReverse = direction === 'asc' ? 1 : -1;
        parseData.sort((x, y) => {
            x = keyValue(x) ? keyValue(x) : '';
            y = keyValue(y) ? keyValue(y) : '';
            return isReverse * ((x > y) - (y > x));
        });
        this.relatedNoteList = parseData;
    }

    handleCreateNewNote() {
        this.template.querySelector('c-account-notes').handleAccountOpen(this.noteContentId);
        this.noteContentId = null;
    }
}